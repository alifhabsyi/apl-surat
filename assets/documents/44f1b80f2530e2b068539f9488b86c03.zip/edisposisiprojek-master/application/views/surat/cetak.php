<!DOCTYPE html>
<html>
<head>
	<title>MEMBUAT CETAK PRINT LAPORAN DENGAN PHP - WWW.MALASNGODING.COM</title>
</head>
<body>

	<center>
		<h2>TUTORIAL CETAK PRINT LAPORAN DENGAN PHP</h2>
		<h4>CONTOH LAPORAN YANG DI PRINT - WWW.MALASNGODING.COM</h4>
	</center>

	<br/>

	<p>
		Tutorial membuat cetak print laporan dengan php. pada tutorial ini kita akan belajar cara membuat cetak laporan pada PHP dengan cara paling mudah.
	</p>

	<p>
		Ini adalah contoh data yang diprint pada tutorial <b>MEMBUAT CETAK PRINT LAPORAN DENGAN PHP</b> dari <b>www.malasngoding.com</b>, halaman ini akan dicetak sesuai dengan format HTML yang terdapat dalam file cetak1.php ini.
	</p>

	<script>
		window.print();
	</script>
	
</body>
</html>